package com.airtribe.aggregatorApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AggregatorApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AggregatorApiApplication.class, args);
	}

}
